import { DatepickerComponent } from './datepicker.component'
export const routes = [
    {
        path: '',
        component: DatepickerComponent
    },
];