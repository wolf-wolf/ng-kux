import { SelectComponent } from './select.component'
export const routes = [
    {
        path: '',
        component: SelectComponent
    },
];